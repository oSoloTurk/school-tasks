﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NDP_TASK_3
{
    class Environments
    {
        public static string CodingSeperator = "\\--\\";
        public static string MusterilerDosyaYolu = "/Musteriler.txt";
        public static string StoklarDosyaYolu = "/Stoklar.txt";
        public static string TedarikcilerDosyaYolu = "/Tedarikciler.txt";
        public static string SatislarDosyaYolu = "/Satislar.txt";
        public static string GiderlerDosyaYolu = "/Giderler.txt";
        public static string SiparislerDosyaYolu = "/Siparisler.txt";
    }
}

